% Attempt to describe the Swedish data
%% Logger coordinate file

fid = fopen('/Users/vercauteren/Documents/SpatialTemperature/DataField/loggersListElev.csv', 'r');
headerLogger = textscan(fid, '%s %s %s %s %s %s %s',1, 'delimiter',','); 
Loggers = textscan(fid, '%s %s %f %f %s %f %f', 'delimiter',',', 'headerLines', 1);  

ID = Loggers{1,1};          %Number identity of the logger (vercauteren's map)
Name = Loggers{1,2};        % Name of the hill
Lat = Loggers{1,3};         %latitude
Long = Loggers{1,4};        %longitude
Orientation = Loggers{1,5}; %north, south, east or west facing
DistanceSea = Loggers{1,6}; %approximate distance to the shore   
Elevation = Loggers{1,7};   %approximate elevation in m

% number of files to read
nfiles=length(ID); %(?)

%% Reading temperature files

% the resampled timeseries are stored in mat files. The timevector is a
% regular one hour frequency time vector.


TempYear = load('/Users/vercauteren/Documents/SpatialTemperature/MatlabFiles/YearlyData/TempYear.mat');
GroundYear = load('/Users/vercauteren/Documents/SpatialTemperature/MatlabFiles/YearlyData/GroundYear.mat');
timevect = load('/Users/vercauteren/Documents/SpatialTemperature/MatlabFiles/YearlyData/timevect.mat');

%indices that have ground temperature measurements
gidx=isnan(GroundYear.GroundYear(1,:));
gidx=find(gidx==0);


% orientation indices
indN=[];indS=[];indE=[];indO=[];indF=[];

for i=1:length(gidx)
    if Orientation{gidx(i)}=='N'
        indN=cat(1,indN,i);
    elseif Orientation{gidx(i)}=='S'
        indS=cat(1,indS,i);
    elseif Orientation{gidx(i)}=='E'
        indE=cat(1,indE,i);
    elseif Orientation{gidx(i)}=='W'
        indO=cat(1,indO,i);
    else
        indF=cat(1,indF,i);
    end
end

%% Read insolation matrix

% Import the file
path='/Users/vercauteren/Documents/SpatialTemperature/DataField/InsolationResults1710/PointLists/';
names={'MayMonthly.txt';'JuneMonthly.txt';'JulyMonthly.txt';'AugMonthly.txt';'SeptMonthly.txt'};
nmonths=13;
MonthlyInso=NaN.*ones(64,nmonths);

for i=1:5
    fileToRead= [path names{i}];
    newData1 = importdata(fileToRead);
    
    % Create new variables in the base workspace from those fields.
    vars = fieldnames(newData1);
    for j = 1:length(vars)
        assignin('base', vars{j}, newData1.(vars{j}));
    end
    
    MonthlyInso(:,i)= data(:,4)./1000;  % monthly average insolation in june, 64 points, one value each
    
end

% get the average daily insolation from the monthly values:
% this should be changed for daily insolation values instead.
DailyInso= MonthlyInso./30;

% Import the files from october until may 
path='/Users/vercauteren/Documents/SpatialTemperature/DataField/InsolationResults250712/PointLists/';
names={'OctMonthly.txt';'NovMonthly.txt';'DecMonthly.txt';'JanMonthly.txt';'FebMonthly.txt';'MarMonthly.txt';'AprMonthly.txt';'MayMonthly2.txt'};


for i=6:nmonths
    fileToRead= [path names{i-5}];
    newData1 = importdata(fileToRead);
    
    % Create new variables in the base workspace from those fields.
    vars = fieldnames(newData1);
    for j = 1:length(vars)
        assignin('base', vars{j}, newData1.(vars{j}));
    end
    
    MonthlyInso(:,i)= data(:,5)./1000;  % monthly average insolation in june, 64 points, one value each
    
end

% get the average daily insolation from the monthly values:
DailyInso= MonthlyInso./30;